# SC Podcasts Plugin

A WordPress plugin for managing podcasts with Supporting Cast API integration. Designed to run in parallel with the Increment plugin during transition, then take over as the primary podcast management system.

## Features

- **Parallel Mode**: Safely run alongside Increment plugin using different post types
- **API Sync**: Automatic synchronization with Supporting Cast API
- **Migration Tools**: Built-in tools to migrate from Increment to SC Podcasts
- **Field Manager Support**: Compatible with existing Field Manager custom fields
- **URL Preservation**: Maintains existing permalink structure

## Installation

1. Upload the `sc-podcasts` folder to `/wp-content/plugins/`
2. Activate the plugin through the WordPress admin
3. Go to SC Podcasts → Settings to configure

## Configuration

### API Settings
1. Navigate to **SC Podcasts → Settings**
2. Enter your Supporting Cast API token
3. Confirm Network ID (default: 10280)
4. Click "Test Connection" to verify

### Operating Modes

#### Parallel Mode (Default)
- Uses `sc_episode` post type
- Uses `sc_premium` taxonomy
- Safe to run with Increment active
- Includes migration tools

#### Production Mode
- Uses `ncrmnt_episode` post type (same as Increment)
- Uses `premium` taxonomy (same as Increment)
- Only enable after deactivating Increment

## Migration Process

### Phase 1: Setup & Testing
1. Install SC Podcasts plugin
2. Configure API settings
3. Run test sync to populate SC episodes
4. Verify episodes are syncing correctly

### Phase 2: Analysis
1. Go to **SC Podcasts → Migration**
2. Click "Analyze Episodes" to compare Increment vs SC data
3. Review matched and unmatched episodes

### Phase 3: Data Migration
1. Click "Copy Episodes" to migrate all Increment posts
2. Enable redirects in settings (optional)
3. Test thoroughly with parallel systems running

### Phase 4: Cutover
1. Deactivate Increment plugin
2. Uncheck "Parallel Mode" in SC Podcasts settings
3. Save settings to switch to production post types
4. Remove redirect rules once verified

## Sync Schedule

- Automatic sync runs every 15 minutes via WP-Cron
- Manual sync available in Settings page
- Incremental updates using `updated_since` parameter

## Field Structure

The plugin maintains compatibility with Increment's field structure:

### Post Fields
- `ncrmnt_notes` - Episode description
- `ncrmnt_duration` - Episode duration
- `ncrmnt_media` - Media information group
  - `media_type` - Audio/Video
  - `media_filesize` - File size
  - `media_link_field` - Audio URL

### SC Integration Fields
- `sc_integration` - Supporting Cast data
  - `episode_id` - SC episode ID
  - `feed_id` - SC feed ID
  - `guid` - Episode GUID
  - `sync_status` - Sync state
  - `last_synced` - Last sync timestamp

### Taxonomy Fields
All existing `premium` taxonomy fields are preserved:
- Created date, homepage, image
- Cloudfront domain, copyright, author
- iTunes settings, access roles

## Feed Mapping

Map Supporting Cast feeds to WordPress taxonomy terms:

1. Go to Settings page
2. Scroll to "Feed Mapping" section
3. Select taxonomy term for each SC feed
4. Mappings are applied during sync

## Troubleshooting

### Episodes Not Syncing
- Verify API token is correct
- Check network ID matches your SC account
- Review sync status in admin columns
- Check error logs for API failures

### Parallel Mode Issues
- Ensure Increment is deactivated before switching modes
- Clear permalinks after mode change
- Check for post type conflicts

### Migration Problems
- Run analysis first to identify issues
- Check for duplicate episodes
- Verify taxonomy mappings
- Review unmatched episodes list

## Development

### File Structure
```
sc-podcasts/
├── sc-podcasts.php          # Main plugin file
├── includes/
│   ├── class-sc-podcasts-cpt.php       # Post type registration
│   ├── class-sc-podcasts-api.php       # API client
│   ├── class-sc-podcasts-sync.php      # Sync service
│   ├── class-sc-podcasts-admin.php     # Admin interface
│   └── class-sc-podcasts-migration.php # Migration tools
└── assets/
    ├── admin.css
    └── admin.js
```

### Hooks & Filters

#### Actions
- `sc_podcasts_before_sync` - Before sync runs
- `sc_podcasts_after_sync` - After sync completes
- `sc_podcasts_episode_synced` - After single episode synced

#### Filters
- `sc_podcasts_sync_params` - Modify API sync parameters
- `sc_podcasts_episode_data` - Filter episode data before save
- `sc_podcasts_feed_mapping` - Modify feed to taxonomy mapping

## Support

For issues or questions about the migration from Increment to SC Podcasts, check the Migration Tools page for diagnostics and analysis tools.
